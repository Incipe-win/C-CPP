#ifndef __TS_INIT_
#define __TS_INIT_

void get_touch(int *x, int *y);
void close_ts();

#endif  // __TS_INIT_
