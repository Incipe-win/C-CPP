#ifndef __PLAY_MUSIC_H_
#define __PLAY_MUSIC_H_

void play_music();
void stop_music();
void next_music();
void pre_music();

#endif  // __PLAY_MUSIC_H_
