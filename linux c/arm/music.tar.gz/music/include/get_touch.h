#ifndef __GET_TOUCH_H_
#define __GET_TOUCH_H_

void get_touch();

#endif  // __GET_TOUCH_H_
