#ifndef __LCD_H_
#define __LCD_H_

void lcd_init();
void lcd_uninit();

#endif  // __LCD_H_
