#ifndef __SHOW_BMP_H_
#define __SHOW_BMP_H_

void show_bmp(int x0, int y0, int w, int h, const char *bmpfile);
void lcd_drawpoint(int w, int h, unsigned int color);

#endif  // __SHOW_BMP_H_
