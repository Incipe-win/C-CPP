# Qt5_Music
使用QT5开发的音乐播放器，具体内容可以查看我的博客  https://blog.csdn.net/daydream13580130043/article/details/79094643#comments
# 项目运行效果
![mymusic](https://github.com/sundial-dreams/Qt5_Music/blob/master/2019-07-22_21-57-03.gif?raw=true)
